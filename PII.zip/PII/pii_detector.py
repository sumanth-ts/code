"""
PII Detection using NeMo Guardrails
====================================
Detects personally identifiable information (PII) in a message and returns
True if PII is found, False otherwise.

Architecture
------------
NeMo Guardrails' ``ActionDispatcher`` is used to register and dispatch the
``check_pii_action`` custom action.  This keeps the detection logic inside the
Guardrails action framework without requiring an external LLM API key.

Supported PII types:
  - Email addresses
  - Phone numbers  (US, international)
  - SSN           (Social Security Numbers)
  - Credit card numbers (Visa, MC, Amex, Discover, Diners, JCB)
  - IPv4 & IPv6 addresses
  - Passport numbers
  - Dates of birth
  - Street / postal addresses
  - Names with titles (Mr., Dr., ...)
  - Aadhaar / PAN  (Indian national IDs)
"""

import asyncio
import re
import logging
from typing import Optional

from nemoguardrails.actions import action
from nemoguardrails.actions.action_dispatcher import ActionDispatcher

# Suppress verbose NeMo / HTTP logging
logging.getLogger("nemoguardrails").setLevel(logging.ERROR)
logging.getLogger("httpx").setLevel(logging.ERROR)


# =============================================================================
# PII Regex Patterns
# =============================================================================
PII_PATTERNS: dict[str, re.Pattern] = {
    "email": re.compile(
        r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
    ),
    "phone_us": re.compile(
        r"\b(?:\+?1[\s\-.]?)?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}\b"
    ),
    "phone_intl": re.compile(
        r"\b\+(?:[1-9]\d{0,2})[\s\-]?(?:\d[\s\-]?){6,14}\d\b"
    ),
    "ssn": re.compile(
        r"\b(?!000|666|9\d{2})\d{3}[- ](?!00)\d{2}[- ](?!0000)\d{4}\b"
    ),
    "credit_card": re.compile(
        r"\b(?:4[0-9]{12}(?:[0-9]{3})?|"       # Visa
        r"5[1-5][0-9]{14}|"                      # MasterCard
        r"3[47][0-9]{13}|"                       # Amex
        r"3(?:0[0-5]|[68][0-9])[0-9]{11}|"      # Diners
        r"6(?:011|5[0-9]{2})[0-9]{12}|"         # Discover
        r"(?:2131|1800|35\d{3})\d{11})\b"       # JCB
    ),
    "ipv4": re.compile(
        r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}"
        r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
    ),
    "ipv6": re.compile(
        r"\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b"
    ),
    "passport": re.compile(r"\b[A-Z]{1,2}[0-9]{6,9}\b"),
    "date_of_birth": re.compile(
        r"\b(?:0?[1-9]|1[0-2])[/\-.](?:0?[1-9]|[12]\d|3[01])[/\-.]\d{2,4}\b"
    ),
    "street_address": re.compile(
        r"\b\d{1,5}\s+(?:[A-Za-z]+\s){1,4}"
        r"(?:St(?:reet)?|Ave(?:nue)?|Blvd|Rd|Road|Lane|Ln|"
        r"Dr(?:ive)?|Court|Ct|Circle|Cir|Way|Pkwy|Pl(?:ace)?)\b",
        re.IGNORECASE,
    ),
    "zipcode_us": re.compile(r"\b\d{5}(?:-\d{4})?\b"),
    "aadhaar":    re.compile(r"\b[2-9]{1}[0-9]{3}\s?[0-9]{4}\s?[0-9]{4}\b"),
    "pan_india":  re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b"),
    "full_name_titled": re.compile(
        r"\b(?:Mr\.?|Mrs\.?|Ms\.?|Dr\.?|Prof\.?)"
        r"\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b"
    ),
}


# =============================================================================
# NeMo Guardrails Custom Action
# =============================================================================
@action(name="check_pii_action")
async def check_pii_action(message: str) -> bool:
    """
    NeMo Guardrails custom action.

    Scans *message* against all PII regex patterns and returns ``True``
    if any pattern matches, ``False`` otherwise.
    """
    for pattern in PII_PATTERNS.values():
        if pattern.search(message):
            return True
    return False


def _get_detected_types(message: str) -> list[str]:
    """Return every PII category name matched in *message*."""
    return [label for label, pat in PII_PATTERNS.items() if pat.search(message)]


# =============================================================================
# PIIDetector — NeMo Guardrails ActionDispatcher wrapper
# =============================================================================
class PIIDetector:
    """
    Registers ``check_pii_action`` inside NeMo Guardrails' ``ActionDispatcher``
    and exposes a clean ``contains_pii`` interface.

    Usage::

        detector = PIIDetector()

        detector.contains_pii("Call me at 555-867-5309")  # True
        detector.contains_pii("Nice to meet you!")         # False
        detector.get_pii_types("SSN is 123-45-6789")       # ['ssn']
    """

    def __init__(self) -> None:
        self._dispatcher = ActionDispatcher(load_all_actions=False)
        self._dispatcher.register_action(check_pii_action, name="check_pii_action")

    # ── async -----------------------------------------------------------------
    async def contains_pii_async(self, message: str) -> bool:
        """
        Async PII check via NeMo Guardrails ActionDispatcher.

        Args:
            message: The text to inspect.

        Returns:
            ``True`` if PII is detected, ``False`` otherwise.
        """
        result, _status = await self._dispatcher.execute_action(
            "check_pii_action",
            params={"message": message},
        )
        return bool(result)

    # ── sync ------------------------------------------------------------------
    def contains_pii(self, message: str) -> bool:
        """
        Synchronous PII check.

        Args:
            message: The text to inspect.

        Returns:
            ``True`` if PII is detected, ``False`` otherwise.
        """
        return asyncio.run(self.contains_pii_async(message))

    # ── diagnostics -----------------------------------------------------------
    def get_pii_types(self, message: str) -> list[str]:
        """
        Return a list of PII category names found in *message*.
        Useful for logging or reporting purposes.
        """
        return _get_detected_types(message)


# =============================================================================
# Module-level convenience functions
# =============================================================================
_detector: Optional[PIIDetector] = None


def _get_detector() -> PIIDetector:
    global _detector
    if _detector is None:
        _detector = PIIDetector()
    return _detector


def contains_pii(message: str) -> bool:
    """
    Module-level shortcut.  Checks *message* for PII and returns True/False.

    Example::

        from pii_detector import contains_pii

        contains_pii("My SSN is 123-45-6789")  # True
        contains_pii("Have a great day!")       # False
    """
    return _get_detector().contains_pii(message)


async def contains_pii_async(message: str) -> bool:
    """Async variant of the module-level :func:`contains_pii`."""
    return await _get_detector().contains_pii_async(message)


# =============================================================================
# Demo / test runner
# =============================================================================
TEST_CASES: list[tuple[str, bool]] = [
    # (message, expected_has_pii)
    ("My email is john.doe@example.com",                True),
    ("Call me at +1 (555) 867-5309",                    True),
    ("SSN: 123-45-6789",                                True),
    ("Card number: 4111 1111 1111 1111",                True),
    ("Server at 192.168.1.100 is down",                 True),
    ("Born on 07/04/1990",                              True),
    ("I live at 42 Baker Street",                       True),
    ("Aadhaar: 2345 6789 0123",                         True),
    ("PAN card: ABCDE1234F",                            True),
    ("Dr. John Smith signed the form",                  True),
    ("Passport: AB1234567",                             True),
    ("The sky is blue.",                                False),
    ("Meeting starts at 3 pm.",                         False),
    ("We released version 2.0 last Tuesday.",           False),
]

COL_W = 48


def run_demo() -> None:
    detector = PIIDetector()

    print("=" * 72)
    print("  NeMo Guardrails – PII Detection Demo")
    print("=" * 72)

    passed = 0
    for msg, expected in TEST_CASES:
        result    = detector.contains_pii(msg)
        pii_types = detector.get_pii_types(msg) if result else []
        ok        = result == expected
        passed   += ok

        status = "PASS" if ok else "FAIL"
        emoji  = "✅" if ok else "❌"
        label  = "PII  " if result else "CLEAN"
        short  = msg[:COL_W - 1] + "…" if len(msg) >= COL_W else msg
        types  = f"  [{', '.join(pii_types)}]" if pii_types else ""
        print(f"  {emoji} {status}  [{label}]  {short!r}{types}")

    print("-" * 72)
    print(f"  Results: {passed}/{len(TEST_CASES)} passed")
    print("=" * 72)


if __name__ == "__main__":
    run_demo()
