# Class-based (recommended)
from pii_detector import PIIDetector

detector = PIIDetector()
detector.contains_pii("My email is john@example.com")  # True
detector.contains_pii("Have a great day!")              # False
detector.get_pii_types("SSN: 123-45-6789")              # ['ssn']

# Module-level shortcut
from pii_detector import contains_pii
contains_pii("Call me at 555-867-5309")  # True

# Async
from pii_detector import contains_pii_async
await contains_pii_async("Dr. John Smith")  # True